# DFSha — Estado del proyecto y continuidad

Actualizado: 2026-09-07 · Etapa activa realizada: **1, especificación formal y arquitectura**.

**Resultado:** los cinco documentos de diseño están creados; el PDF disponible fue leído completo y los requisitos tienen trazabilidad y evidencia futura. No existe implementación funcional, despliegue ni prueba de servicio aprobada. La revisión docente y las aclaraciones abiertas no se presuponen realizadas.

<a id="inventario"></a>
## 1. Inventario y materiales consultados

Carpeta de trabajo: `F:\DFSha`, Windows PowerShell. Al comenzar solo había dos archivos bajo `docs/`; se buscaron archivos ocultos e instrucciones `AGENTS.md` en la carpeta y su raíz. No existían `docs/estado.md`, código, tests, contratos, configuración, README, `.git`, `.agents` ni `.codex` locales. El archivo global de instrucciones consultado estaba vacío (0 bytes), sin reglas adicionales. No se accedió a conversaciones, memorias o archivos de otros proyectos de ChatGPT.

| Documento consultado | Relevancia y alcance de lectura |
| --- | --- |
| [SI3007-262-proyecto1-dfs.docx.pdf](enunciado/SI3007-262-proyecto1-dfs.docx.pdf) | Fuente principal. **Siete páginas leídas íntegramente**, extracción por página y revisión visual de pp. 2, 5, 6 y 7 para RNF8, comunicaciones, entregables, cronograma y rúbrica. Tamaño: 203.468 bytes. |
| [Prompts_Codex_DFSha_Opcion1_CS.md](propuesta/Prompts_Codex_DFSha_Opcion1_CS.md) | Guía complementaria completa, 761 líneas. Propone stack y once etapas; no prueba decisiones de otros chats ni resultados implementados. |
| Solicitud del usuario de etapa 1 | Opción 1, reglas de corrección, parámetros a evaluar, semántica snapshot propuesta, cinco documentos y límite de alcance. |
| [Fuentes técnicas oficiales](decisiones.md#fuentes) | Capacidades/compatibilidad documental de gRPC/Protobuf, etcd, SQLite, bibliotecas de seguridad, Docker y redes/discos cloud. Consultadas el 2026-09-07; no equivalen a pruebas de integración. |

Identidad de los archivos fuente, sin modificaciones realizadas sobre ellos:

```text
PDF SHA-256
0EC8CC4CF92F9CF9345D5CF147D096A9CC74F78146AABCE823D3890A31B446BF

Guía SHA-256
755D2BEBC288133E54E4F3161A433C35E6D08A9F0A7C8DCE9B9B031E41C902B3
```

Mapa de lectura del PDF:

| Página | Contenido revisado |
| --- | --- |
| 1 | Identificación del curso, nota sobre refinamiento hasta el 26 de agosto, objetivo, cliente/servicio, RF1–RF3 y RNF1. |
| 2 | RNF2–RNF8, opciones 1/2 y comienzo del marco teórico. RNF8 no añade requisitos concretos. |
| 3 | Discusión de bloques/objetos y referencias GFS/HDFS; material teórico, no una orden de instalar esos sistemas. |
| 4 | Definición del equipo, arquitectura según opción, ejemplos y ejecución sobre Internet. |
| 5 | Roles, cinco relaciones, ejemplos de protocolos, VMs, API por nodo y tres entregables con sus contenidos. |
| 6 | Semanas 6–13, hitos y primeras cuatro filas de evaluación. Semanas 9/11 vacías. |
| 7 | Replicación/consistencia, seguridad, video/informe/GitHub y recursos sugeridos. Numeración 5 repetida, sin corregirla al citar. |

<a id="archivos"></a>
## 2. Archivos entregados y alcance

| Archivo creado | Contenido |
| --- | --- |
| [especificacion.md](especificacion.md) | Objetivo, problema, actores, alcance, RF1/RF2/RF3, rutas, modos, snapshots, offsets, locks, borrado, permisos, casos/metas y Q01–Q07. |
| [arquitectura.md](arquitectura.md) | Evolución H1–H3/final, responsabilidades/estado, metadatos, cinco relaciones, diagramas inicial/final/despliegue/secuencias, R/W, fallos, seguridad e infraestructura. |
| [decisiones.md](decisiones.md) | D01–D20, alternativas, clasificación de ejemplos, capacidades consultadas, compatibilidad pendiente y registro RNF8. |
| [matriz-requisitos.md](matriz-requisitos.md) | RF/RNF y obligaciones transversales, entregables, hitos, rúbrica, reglas USR, criterios, componentes y pruebas/evidencias previstas. |
| [estado.md](estado.md) | Inventario, acciones/resultados, límites, plan y continuidad. |
| [lectura-pdf.txt](evidencias/etapa1/lectura-pdf.txt) | Evidencia auxiliar: extracción íntegra por página con hash/método. El PDF sigue siendo la autoridad de contenido y formato. |
| [verificacion-documental.json](evidencias/etapa1/verificacion-documental.json) | Resultado de comprobaciones estructurales de los documentos; no certifica funcionamiento del DFS. |

Los diagramas se entregan en Mermaid editable dentro de arquitectura.md: componentes/despliegue del monolito, componentes finales, mediación del control, secuencia de escritura, secuencia de lectura y despliegue de VMs. La sintaxis y el alcance se revisan como documentación; no representan procesos desplegados.

<a id="verificacion"></a>
## 3. Acciones ejecutadas y estados reales

| Estado | Acción/comando realizado | Resultado y alcance |
| --- | --- | --- |
| EJECUTADO | `Get-Location`, `rg --files --hidden` con exclusiones iniciales y búsquedas de AGENTS.md. | Inventario inicial de dos documentos; carpeta actual confirmada; sin instrucciones locales adicionales. |
| FALLIDO | `git status --short`. | `fatal: not a git repository`. Diagnóstico: no hay Git inicializado. No se crearon commits, ramas ni remoto. |
| EJECUTADO | `Get-Content` de la guía; relectura por rangos con `-Encoding UTF8`. | Lectura completa. La primera visualización tenía caracteres mal decodificados por PowerShell; se corrigió la lectura, sin modificar el archivo. |
| EJECUTADO | `Get-Item` y `Get-FileHash ... -Algorithm SHA256` del PDF. | Tamaño/hash identificados; el hash posterior coincide con el inicial. |
| BLOQUEADO POR ENTORNO | `Get-Command python,python3,pdftotext,mutool,...`; `py -0p` y `py -c ...`. | No hay Python registrado (`No installed Pythons found!`) ni lector PDF de consola encontrado en PATH. No se ejecutó código Python del proyecto. |
| EJECUTADO | `Get-Command py,node,npm,dotnet,...`; `node --version`. | Node.js v22.16.0 disponible; py es solo lanzador sin Python registrado. Docker no fue encontrado en PATH; una instalación fuera de PATH no fue verificada. |
| FALLIDO, RESUELTO PARA LECTURA | `npm.cmd cache ls pdf`. | EPERM al leer caché predeterminada. Se usó aprobación del entorno para descargar un lector en carpeta temporal; no se cambió el stack del proyecto. |
| EJECUTADO | `npm.cmd install --prefix "$env:TEMP\dfsha-stage1-pdf" --cache "$env:TEMP\dfsha-stage1-npm-cache" --no-save --ignore-scripts pdfjs-dist@5.4.149`. | Descarga temporal autorizada; tres paquetes agregados. Herramienta de lectura documental, no dependencia de DFSha. |
| EJECUTADO | Script temporal Node con PDF.js: `getDocument`, `getTextContent` para páginas 1–7; renderizado con canvas de pp. 2/5/6/7 y visualización. | Siete páginas extraídas y leídas; tablas/elipsis contrastadas visualmente. Texto conservado en lectura-pdf.txt. |
| EJECUTADO | Consultas web a documentación oficial y fichas de paquetes mantenidas. | Fuentes enlazadas en decisiones.md; capacidades y mínimos Python contrastados. No se ejecutó stack DFSha. |
| EJECUTADO | Edición de cinco Markdown y generación de evidencia textual. | Únicamente documentación; archivos originales preservados. |
| EJECUTADO | Auditoría Node de existencia, enlaces/anchors locales, estructura de tablas, cobertura de IDs y hashes de fuentes. | Resultado concreto en verificacion-documental.json; las verificaciones de servicio no están incluidas. |
| PENDIENTE | Generar/renderizar diagramas con la toolchain documental final y exportar informe. | E1 entrega fuente Mermaid; la revisión visual del PDF fuente no debe confundirse con renderizado de los diagramas de diseño. |
| PENDIENTE | RPC real, pruebas RF/RNF, benchmark, Docker y despliegue cloud. | Corresponden a etapas posteriores; ninguna cuenta como aprobada. |

No se instalaron Python, Docker, etcd ni dependencias de aplicación. No se creó estructura `src/`, `proto/`, `tests/` o `deploy/`. No se aprovisionaron VMs, direcciones, claves de servicio ni certificados. Las verificaciones de los hitos siguen PENDIENTES, aunque su diseño esté completo.

<a id="restricciones"></a>
## 4. Restricciones, información faltante y riesgos

El entorno permite escritura de proyecto en `F:\DFSha` y temporales, con restricciones de red/permisos. La lectura del PDF se resolvió con una herramienta temporal aprobada; no queda bloqueada la especificación por falta de PDF.

| Situación | Estado y siguiente acción |
| --- | --- |
| Sin Python disponible y Docker no encontrado en PATH | BLOQUEADO POR ENTORNO para ejecutar aquí ese stack actualmente. Resolver al iniciar E2, instalando/configurando herramientas autorizadas o usando un entorno Linux permitido. |
| Sin repositorio Git local, remoto ni README | PENDIENTE E2: inicializar estructura/Git y definir remoto real con el equipo cuando corresponda; no inventar URL. |
| Cuenta AWS Academy/GCP, IAM, créditos, cuotas, zonas, direcciones y dominio | PENDIENTE de información/verificación. No se intentó un despliegue ni se ha demostrado una denegación del proveedor. Se diseñó inventario/red/capacidad en A10–11. |
| Integrantes, responsabilidades, fechas calendario y custodios de claves | PENDIENTE del equipo; no se asignan nombres ni fechas de entrega inferidas. |
| Versión definitiva docente y aclaraciones | Q01–Q07 registradas en especificación. Mantener la fuente actual hasta recibir material accesible posterior. |
| Binding Python de etcd/protos y versiones exactas | PENDIENTE E2: prueba de compatibilidad antes de comprometerse con un cliente. La documentación general no prueba que un paquete tercero sea compatible. |
| Tres miembros por host físico/zona | Solo VMs/volúmenes independientes diseñados; independencia física real requiere verificar proveedor/colocación. Tres contenedores locales no acreditan pérdida de host. |
| Coste de etcd, introspección por bloque, GC y colocalización | Riesgos de rendimiento a medir; topes/paginación y carga acotada definidos. No existe resultado de benchmark. |

La interpretación de RNF4 para archivos pequeños, el conjunto exacto de mecanismos RNF6, el nivel de transparencia, la semántica de RF3 y la mediación CN–etcd–CN permanecen explícitos para revisión docente. No impiden completar el diseño solicitado y no se declaran aceptados por el docente.

<a id="plan"></a>
## 5. Plan de ejecución y entregas

El PDF es autoridad para las semanas. Las etapas son organización interna tomada de la guía, compatibles con el cronograma. Las semanas 9/11 no incorporan hitos docentes nuevos. No convertir la fecha de esta sesión a una semana del curso sin calendario del grupo.

| Etapa | Trabajo y dependencia | Resultado verificable | Hito / estado real |
| --- | --- | --- | --- |
| 1 | Leer fuentes, inventariar y formalizar. | Cinco documentos, matriz, decisiones y diagramas; fuente íntegra revisada. | Semana 7, especificación; EJECUTADO documentalmente. Revisión/entrega académica pendiente. |
| 2 | Partir del diseño E1; preparar Python/toolchain/entorno y contratos. | src/dfsha por módulos, proto/, tests/, deploy/, scripts/, dependencias fijadas, stubs, configuración sin secretos, TLS desarrollo, logging y docs/protocolos.md. RPC real y acceso etcd v3 comprobados. | Preparación H1; PENDIENTE. |
| 3 | Con E2 verificable, implementar un cliente y un servidor modular. | RF1/RF2 completos, persistencia, TLS/auth y cifrado local; pruebas de árbol, transferencias/interrupciones; docs/hito1.md y referencia Git. | Semana 8, H1; PENDIENTE. |
| 4 | Solo después de H1 validado, separar CN/DN. | Registro/descubrimiento, particionamiento en bloques, streams a varios DN, lectura/escritura distribuida, APIs S/S y docs/hito2.md. Si R=1/W=1 temporal, declarar ausencia de HA. | Semana 10, H2; PENDIENTE. |
| 5 | Sobre el sistema distribuido, implementar RF3. | Handles/snapshots, offsets, PatchBlock, locks/fencing, concurrencia por bloque y tombstones con pruebas. | Hacia H3; PENDIENTE. |
| 6 | Replicar y recuperar datos usando las mismas versiones/operaciones. | R=3/W=2, recibos auténticos, retry idempotente, corrupción/reparación, prueba de cuarto DN y GC segura. | Hacia H3; PENDIENTE. |
| 7 | Migrar estado de control a autoridad compartida. | Tres CN/tres etcd, Txn/CAS, leases/fencing distribuidos, failover, quórum, backup/restore y migración verificada. | Hacia H3; PENDIENTE. |
| 8 | Completar y auditar seguridad transversal. | TLS/mTLS, usuario/grupo/ACL, autorización DN, cifrado y claves recuperables; docs/seguridad.md y docs/hito3.md con pruebas E5–8. | Semana 12, H3; PENDIENTE. |
| 9 | Con sistema verificado y cuenta disponible, desplegar. Preparación de acceso desde E1. | VMs académicas distintas, C/S por Internet y S/S privado, persistencia y prueba de perder host desde cliente externo; docs/despliegue.md. | Antes de final; PENDIENTE. |
| 10 | Consolidar pruebas continuas y cargas según recursos. | Metodología, scripts, CSV/JSON, gráficas reales y docs/pruebas-resultados.md; cubrir tres dimensiones RNF1. | Antes de final; PENDIENTE. |
| 11 | Auditar PDF/clarificaciones contra implementación y evidencia. | Informe PDF/Word revisado, GitHub reproducible, video 10–15 min y docs/auditoria-final.md. | Semana 13, final; PENDIENTE. |

Los contenidos obligatorios del informe y la rúbrica completa están en [matriz, entregables](matriz-requisitos.md#entregables) y [matriz, evaluación](matriz-requisitos.md#rubrica). La suma de pesos es 100%; no se inventan aspectos donde el PDF deja elipsis.

<a id="aceptacion"></a>
## 6. Aceptación de etapa 1

| Criterio solicitado | Verificación documental / estado |
| --- | --- |
| PDF íntegro y fuentes identificadas | CUMPLE: siete páginas leídas, hash y extracción; revisión visual de páginas críticas y fuentes técnicas enlazadas. |
| Todos los requisitos/obligaciones en matriz | CUMPLE: RF1–3, RNF1–8, objetivo, definición/opción 1, comunicaciones/APIs, infraestructura, entregables, semanas/hitos y siete criterios de evaluación. |
| Criterio observable y evidencia prevista por requisito | CUMPLE documentalmente: matriz y catálogo T-ID, con etapas/componentes previstos. No son resultados funcionales. |
| RF3 con semántica y plan | CUMPLE: S6, A6–8; modos/offsets/EOF, snapshots, write/close, locks, escritores compatibles y borrado. Implementar E5, coordinación final E7. |
| Cinco relaciones descritas | CUMPLE: A4; CN–CN mediado por etcd, con Q05 registrada. |
| Monolito y distribuido diferenciados | CUMPLE: A1–2 y diagramas; H1 se conserva y no reclama HA. |
| Disponibilidad incluye datos/control/metadatos/acceso | CUMPLE en diseño: A8–10 también cubren claves, DNS/entradas, quórum y dominios de fallo. |
| Propuestas separadas de PDF | CUMPLE: clases PDF/USR/INT/DIS, D01–D20 y tratamiento de ejemplos/elipsis. |
| Cinco archivos existentes y coherentes | CUMPLE documentalmente, sujeto al resultado conservado de auditoría estructural y revisión cruzada. |

**Etapa 1 completa como entrega de especificación y diseño del archivo disponible.** Esto no declara aprobación docente, cumplimiento funcional final ni validación cloud. Las consultas abiertas y la instalación/toolchain de E2 se conservan visibles.

<a id="retomar"></a>
## 7. Instrucciones para continuar en otra sesión

Leer primero este estado, [matriz-requisitos.md](matriz-requisitos.md), [decisiones.md](decisiones.md) y cualquier AGENTS.md nuevo; inventariar cambios antes de editar. Preservar PDF/guía y la evidencia del monolito cuando exista. Ejecutar solo la etapa autorizada y sus dependencias imprescindibles. Actualizar matriz al recibir aclaraciones docentes; no copiar propuestas técnicas como requisitos del PDF.

El siguiente trabajo es **etapa 2: contratos, estructura y entorno reproducible**. Resolver Python/Docker según entorno disponible, fijar versiones compatibles y verificar stubs/RPC/etcd; preparar los contratos de todas las relaciones sin adelantar RF1/RF2 funcionales ni distribución del hito 2. La estructura modular no elimina el servidor único del hito 1. Registros de comandos, errores y pruebas reales deben actualizar este estado al cerrar esa etapa.

Reglas que deben persistir: RF3 final obligatorio; bytes finales cliente–DataNode; lectura/escritura mediante varios nodos; ubicación dinámica; W de datos separado de quórum; publicación atómica; fencing en commit; deltas compatibles sin sobrescribir cambios ajenos; tombstones/GC seguros; HA también de control/metadatos/entrada/claves; autorización DN; criptografía/consenso de bibliotecas; evidencia local y cloud diferenciada. Nada no ejecutado cuenta como aprobado.
